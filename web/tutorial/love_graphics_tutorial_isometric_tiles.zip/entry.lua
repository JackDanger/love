-- Graphics Tutorial: Isometric Tiles
-- How to create and display an isometric grid.

main = {
	
	init = function()
	
		-- add our images and determine the size
		dirt = love.objects:newImage("dirt.png");
		grass = love.objects:newImage("grass.png");
		gridsize = 8; -- our grid will be 8x8
		gridheight = 2; -- our grid will be 2 "boxes" high
		width = dirt:getWidth(); -- the width of the tile
		height = dirt:getHeight(); -- the height of the tile
		tile_height = 32; -- the height of the isometric "cube" which is actually the top surface (the tile)
		
		-- first, create our arrays for holding the tile information
		-- system: tiles[level][x][y]
		tiles = {}
		for level = 1,gridheight do
			tiles[level] = {}
			for x = 1,gridsize do
				tiles[level][x] = {}
				for y = 1,gridsize do
					tiles[level][x][y] = 0; -- this means that there is no tile here
				end
			end
		end
		
		-- let's fill our grids up with some nice dirt and grass
		for x = 1,gridsize do
			for y = 1,gridsize do
				tiles[1][x][y] = dirt;
				tiles[2][x][y] = grass;
			end
		end
		
		-- now let's remove the middle of the top layer to get some sweet "3D" gray-fix
		for x = 2,gridsize-1 do
			for y = 2,gridsize-1 do
				tiles[2][x][y] = 0;
			end
		end
		-- and add one random one
		tiles[2][2][3] = grass;
		
		-- first we need to find the center point of the screen
		x_position = 800 / 2;
		y_position = 600 / 2;
		
		-- this is for the mouse moving
		mousex = 0;
		mousey = 0;
		
	end,
	
	update = function(dt)
	
		if mouse:isDown(LOVE_MOUSE_RIGHT) then
			if mouse:getX() ~= mousex then
				x_position = x_position + (mouse:getX() - mousex);
				mousex = mouse:getX();
			end
			if mouse:getY() ~= mousey then
				y_position = y_position + (mouse:getY() - mousey);
				mousey = mouse:getY();
			end
		end
		
	end,
	
	-- all the code in here is to
	render = function()
	
		for level = 1,gridheight do
			for x = 1,gridsize do
				for y = 1,gridsize do
					if tiles[level][x][y] ~= 0 then
						tiles[level][x][y]:render(x_position + ((x-y) * (width / 2)), y_position + ((x+y) * (tile_height / 2)) - (level * tile_height) - (gridsize * (tile_height / 2)));
						-- the " - (gridsize * tile_height)) " is to position the grid in the middle of the y_position
					end --if
				end --for
			end --for
		end --for
		
		game:drawString(50, 50, "Use the right mouse button to move around.");
		game:drawString(50, 80, "pos: " .. x_position .. "x" .. y_position);
		
	end,
	
	mousepressed = function(x, y, button)
	
		if button == LOVE_MOUSE_RIGHT then
			mousex = x;
			mousey = y;
		end
		
	end

} -- main
